# Azure Devops Extension


## How to create package extension:

```bash
tfx extension create --manifest-globs vss-extension.json
```